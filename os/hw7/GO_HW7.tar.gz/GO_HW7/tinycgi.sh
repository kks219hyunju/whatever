#!/bin/bash

## Minimal cgi demo wrapper to show how the CGI environment works.
## Header should be in child program, but this is a simple demo

## dump the env as if it were a shell.
## Human: Look for URL parameters in the outp

./a.out -rL /var/log/osLogfile.log -H file.txt;

env
